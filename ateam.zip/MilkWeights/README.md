README

Course: cs400
Semester: Spring 2020
Project name: Milk Weights for Chalet Cheese Factory
Team Members:
1. Logan Kroes,    Lecture 001,  lkroes@wisc.edu
2. Saurav Chandra, Lecture 001,  schandra8@wisc.edu
3. John Wirth,     Lecture 001,  jjwirth2@wisc.edu
4. Shashank Bala,  Lecture 001,  sbala2@wisc.edu
5. Brock Humblet,  Lecture 001,  bhumblet@wisc.edu
 

Which team members were on same xteam together?
John Wirth & Saurav Chandra

Other notes or comments to the grader:

[place any comments or notes that will help the grader here]
